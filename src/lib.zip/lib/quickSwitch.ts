export const QUICK_SWITCH = [    // or "/notes/daily/2026-02-14" later
  { label: "Daily Note", href: "/notes/daily/" },
  { label: "Philosophy", href: "/notes/philosophy/" },
  { label: "Systems", href: "/notes/systems/" },
] as const;
